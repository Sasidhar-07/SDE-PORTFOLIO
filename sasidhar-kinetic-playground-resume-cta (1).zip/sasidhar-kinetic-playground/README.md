# Sasidhar — Living Systems Portfolio

A cinematic, interactive portfolio for Pannuru Sasidhar, built with Next.js, React and custom CSS/Canvas motion.

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Production build

```bash
npm run build
npm start
```

## Experience notes

- Pointer-reactive particle atmosphere and portrait perspective
- Scroll-revealed editorial storytelling
- Animated, interactive product study panels for three projects
- Selectable capability layers
- Live Bengaluru clock and responsive navigation
- Reduced-motion support

The portrait and resume are included in `public/`. Project destinations and profile links are embedded in `app/page.tsx` and should be checked before publishing.

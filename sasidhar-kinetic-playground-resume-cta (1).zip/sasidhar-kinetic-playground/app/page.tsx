'use client';

import Image from 'next/image';
import { useEffect, useRef, useState } from 'react';
import { ArrowDown, ArrowUpRight, Github, Linkedin, Menu, X, Zap, Code2, Layers3, Sparkles, MoveUpRight } from 'lucide-react';

const projects = [
  {n:'01',name:'DevPulse Intelligence',kind:'AI / DEVELOPER INTELLIGENCE',desc:'A repository intelligence platform that reads engineering signals across pull requests, issues and commits to surface code health and release risk.',stack:['React','Node.js','Express','SSE','Docker'],repo:'https://github.com/Sasidhar-07/ai-developer-intelligence-platform',live:'https://ai-developer-intelligence-platform.vercel.app',metric:'92',label:'HEALTH INDEX',shape:'pulse'},
  {n:'02',name:'SprintGrid Cloud',kind:'REAL-TIME COLLABORATION',desc:'A multi-workspace sprint and Kanban environment for task flow, team capacity, sprint velocity and live collaboration.',stack:['React','Node.js','REST','SSE','Docker'],repo:'https://github.com/Sasidhar-07/cloud-project-collaboration-platform',live:'https://cloud-project-collaboration-platfor.vercel.app',metric:'34',label:'SPRINT POINTS',shape:'grid'},
  {n:'03',name:'AI Support Workflow',kind:'APPLIED AI / OPERATIONS',desc:'A support operations workflow with live ticket queues, severity classification and AI-assisted response drafting.',stack:['React','Node.js','Express','REST','SSE'],repo:'https://github.com/Sasidhar-07/ai-support-workflow-platform',live:'https://ai-support-workflow-platform.vercel.app',metric:'LIVE',label:'EVENT STREAM',shape:'support'}
];
const groups=[
 {name:'FRONTEND',line:'Interfaces with a pulse.',items:['React','JavaScript','HTML5','CSS3','Tailwind CSS','Vite','React Native']},
 {name:'BACKEND',line:'Services. Contracts. Events.',items:['Node.js','Express.js','FastAPI','REST APIs','Server-Sent Events']},
 {name:'DATA',line:'Make information useful.',items:['PostgreSQL','SQL','JSON Persistence','LocalStorage Caching']},
 {name:'ENGINEERING',line:'Build it. Ship it. Own it.',items:['Python','Docker','Docker Compose','Git','GitHub','Postman','OOP','DBMS','Agile / Scrum']},
 {name:'APPLIED AI',line:'Intelligence with purpose.',items:['Machine Learning','Generative AI','Explainable ML']}
];

function MotionField(){
 const ref=useRef<HTMLCanvasElement>(null);
 useEffect(()=>{
  const canvas=ref.current,ctx=canvas?.getContext('2d'); if(!canvas||!ctx)return;
  let w=0,h=0,raf=0,mx=-500,my=-500;
  const reduced=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const dots=Array.from({length:75},()=>({x:Math.random(),y:Math.random(),r:Math.random()*2+0.5,v:Math.random()*0.7+0.2,a:Math.random()*6.28}));
  const resize=()=>{w=innerWidth;h=innerHeight;const d=Math.min(devicePixelRatio||1,1.5);canvas.width=w*d;canvas.height=h*d;ctx.setTransform(d,0,0,d,0,0)};
  const pointer=(e:PointerEvent)=>{mx=e.clientX;my=e.clientY};
  const draw=(t:number)=>{ctx.clearRect(0,0,w,h);dots.forEach((p,i)=>{const x=p.x*w+Math.sin(t*.0004+p.a)*22,y=((p.y*h-t*p.v*.018)%(h+40)+h+40)%(h+40)-20;const dx=x-mx,dy=y-my,d=Math.hypot(dx,dy);ctx.beginPath();ctx.arc(x+(d<150?dx*.08:0),y+(d<150?dy*.08:0),p.r,0,Math.PI*2);ctx.fillStyle=`rgba(255,92,42,${.22+.35*(.5+.5*Math.sin(t*.002+i))})`;ctx.fill();if(i%3===0){ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+Math.sin(p.a)*32,y+Math.cos(p.a)*32);ctx.strokeStyle='rgba(255,92,42,.13)';ctx.stroke()}});if(!reduced)raf=requestAnimationFrame(draw)};
  resize();draw(0);if(!reduced)raf=requestAnimationFrame(draw);addEventListener('resize',resize);addEventListener('pointermove',pointer);
  return()=>{cancelAnimationFrame(raf);removeEventListener('resize',resize);removeEventListener('pointermove',pointer)};
 },[]);
 return <canvas ref={ref} className="motion-field" aria-hidden="true"/>;
}

function Reveal({children,className=''}:{children:React.ReactNode,className?:string}){
 const ref=useRef<HTMLDivElement>(null);
 useEffect(()=>{const el=ref.current;if(!el)return;const io=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('is-visible');io.unobserve(e.target)}}),{threshold:.12});io.observe(el);return()=>io.disconnect()},[]);
 return <div ref={ref} className={`reveal ${className}`}>{children}</div>;
}
function Ticker(){return <div className="ticker"><div>{Array.from({length:4},(_,i)=><span key={i}>THINK <b>✳</b> BUILD <b>✳</b> BREAKTHROUGH <b>✳</b> REPEAT <b>✳</b> </span>)}</div></div>}
function ProductMock({project}:{project:typeof projects[number]}){
 return <div className={`mock mock-${project.shape}`}>
  <div className="mock-head"><span><i/> PRODUCT / LIVE PREVIEW</span><span>BUILD_0{project.n}</span></div>
  {project.shape==='pulse'?<><div className="mock-stat"><small>ENGINEERING HEALTH</small><strong>0{project.metric}<em>.8</em></strong><b>↗ 8.4% THIS CYCLE</b></div><div className="wave"><svg viewBox="0 0 600 140" preserveAspectRatio="none"><path d="M0 100 C40 90 50 25 95 55 S150 120 195 67 S255 20 300 70 S365 115 405 55 S470 22 510 65 S565 30 600 10"/></svg></div><div className="mock-foot"><span>PR THROUGHPUT</span><b>+18.6%</b><span>OPEN ISSUES</span><b>12</b></div></>:project.shape==='grid'?<div className="board">{[['QUEUE','API schema','Edge audit','Design handoff'],['IN BUILD','Event sync','Workspace roles'],['SHIPPED','Auth flow','Sprint metrics']].map((c,i)=><div key={c[0]}><small>{c[0]}</small>{c.slice(1).map((v,j)=><article key={v} style={{'--n':j+i} as React.CSSProperties}><i/>{v}</article>)}</div>)}</div>:<div className="inbox"><div>{['Payment retry loop','Workspace access','Export not completing','Webhook delay'].map((v,i)=><article key={v}><small>#20{41-i}</small><b>{v}</b><em>{i===0?'HIGH':'MED'}</em></article>)}</div><aside><span>AI RESPONSE ASSIST</span><b>Suggested reply</b><p>We’re checking the event trail and will share an update shortly.</p><strong>CONFIDENCE · HIGH</strong></aside></div>}
  <div className="mock-bottom"><span>{project.name.toUpperCase()}</span><b>{project.metric} <small>{project.label}</small></b></div>
 </div>
}

export default function Home(){
 const [project,setProject]=useState(0),[group,setGroup]=useState(0),[menu,setMenu]=useState(false),[clock,setClock]=useState('--:--'),[progress,setProgress]=useState(0),[pointer,setPointer]=useState({x:0,y:0});
 useEffect(()=>{const tick=()=>setClock(new Intl.DateTimeFormat('en-IN',{timeZone:'Asia/Kolkata',hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date()));tick();const timer=setInterval(tick,30000);const scroll=()=>setProgress(Math.min(100,scrollY/(document.documentElement.scrollHeight-innerHeight)*100||0));const move=(e:PointerEvent)=>setPointer({x:e.clientX/innerWidth-.5,y:e.clientY/innerHeight-.5});addEventListener('scroll',scroll,{passive:true});addEventListener('pointermove',move);return()=>{clearInterval(timer);removeEventListener('scroll',scroll);removeEventListener('pointermove',move)}},[]);
 const p=projects[project];
 return <main className="site">
  <MotionField/><div className="grain"/><div className="reading-progress" style={{transform:`scaleX(${progress/100})`}}/>
  <header className="topbar"><a href="#top" className="wordmark"><span className="mark">S<span>✳</span></span><span>SASIDHAR<small>SOFTWARE / HUMAN / IDEAS</small></span></a><div className="top-status"><i/> OPEN TO OPPORTUNITIES <b>{clock} IST</b></div><button className="menu-btn" onClick={()=>setMenu(!menu)} aria-label="Toggle menu">{menu?<X/>:<Menu/>}</button><nav className={menu?'menu open':'menu'}><a href="#work" onClick={()=>setMenu(false)}>WORK ↘</a><a href="#toolkit" onClick={()=>setMenu(false)}>TOOLKIT ↘</a><a href="#story" onClick={()=>setMenu(false)}>STORY ↘</a><a className="menu-contact" href="mailto:sasidharp394@gmail.com">LET'S TALK <MoveUpRight size={15}/></a></nav></header>
  <section className="hero" id="top">
   <div className="hero-topline"><span>PORTFOLIO / 2026</span><span>INDEPENDENT DEVELOPER <b>●</b> BENGALURU, INDIA</span></div>
   <div className="hero-main">
    <div className="hero-copy"><p className="micro reveal"><span className="micro-line"/> NOT HERE TO MAKE MORE OF THE SAME.</p><h1><span className="word-one">MAKE</span><span className="word-two">DIGITAL</span><span className="word-three">THINGS</span><span className="word-four">MATTER<span className="period">.</span></span></h1><p className="hero-description">I'm <b>Pannuru Sasidhar</b> — a Software Development Engineer turning complex ideas into useful, expressive software.</p><div className="hero-ctas"><a className="button-hot" href="#work">EXPLORE MY WORK <ArrowDown size={17}/></a><a className="resume-link" href="/Sasidhar-Resume.pdf" target="_blank" rel="noreferrer" aria-label="Open Pannuru Sasidhar resume PDF"><span className="resume-icon"><ArrowUpRight size={20}/></span><span className="resume-copy"><strong>VIEW MY RESUME</strong><small>EXPERIENCE · PROJECTS · SKILLS</small></span><span className="resume-format">PDF ↗</span></a></div></div>
    <div className="portrait-scene" style={{'--px':`${pointer.x*18}px`,'--py':`${pointer.y*14}px`} as React.CSSProperties}><div className="portrait-word">HUMAN<br/>INPUT<span>✳</span></div><div className="portrait-sticker">BUILT<br/>WITH<br/>CURIOSITY</div><div className="portrait-cutout"><Image src="/sasidhar-portrait.png" alt="Pannuru Sasidhar" fill priority sizes="(max-width: 800px) 80vw, 44vw" style={{objectFit:'cover',objectPosition:'center 18%'}}/></div><div className="portrait-caption">FIG. 01 — THE BUILDER / <b>NOT A TEMPLATE</b></div><div className="orbit-stamp">PS · PS · PS · PS ·</div></div>
   </div>
   <div className="hero-bottom"><span>SCROLL TO SEE WHAT I MEAN <ArrowDown size={14}/></span><span>FULL-STACK ENGINEERING <b>✳</b> APPLIED AI <b>✳</b> PRODUCT THINKING</span><span>001 — 005</span></div>
  </section>
  <Ticker/>
  <section className="manifesto" id="story"><div className="section-tag"><span>01 / THE POINT OF VIEW</span><span>LESS TALK. MORE MAKING.</span></div><Reveal className="manifesto-title"><h2>Software should<br/>do more than <i>work.</i></h2><div className="manifesto-aside"><Sparkles size={30}/><p>It should feel obvious to use, thoughtful under the hood, and worth coming back to.</p></div></Reveal><div className="manifesto-bottom"><span>MY APPROACH</span><div><b>01</b> MAKE COMPLEXITY FEEL SIMPLE</div><div><b>02</b> DESIGN FOR THE HUMAN ON THE OTHER SIDE</div><div><b>03</b> BUILD SYSTEMS THAT HOLD UP</div></div></section>
  <section className="work" id="work"><div className="section-tag"><span>02 / SELECTED WORK</span><span>REAL BUILDS / REAL LEARNING</span></div><div className="work-heading"><Reveal><h2>THINGS I'VE<br/><i>PUT INTO MOTION.</i></h2></Reveal><div className="work-side">THREE BUILDS<br/>ONE CONSTANT:<br/><b>MAKE IT USEFUL ↘</b></div></div>
   <div className="work-tabs">{projects.map((v,i)=><button key={v.n} className={project===i?'active':''} onClick={()=>setProject(i)}><span>{v.n}</span>{v.name}<MoveUpRight size={15}/></button>)}</div>
   <div className="project-stage" key={p.n}><div className="project-info"><span className="project-type">/{p.kind}</span><h3>{p.name}<sup>↗</sup></h3><p>{p.desc}</p><div className="tags">{p.stack.map(s=><span key={s}>{s}</span>)}</div><div className="project-actions"><a href={p.repo} target="_blank" rel="noreferrer"><Github size={16}/> SOURCE CODE <ArrowUpRight size={13}/></a><a href={p.live} target="_blank" rel="noreferrer">OPEN LIVE <ArrowUpRight size={13}/></a></div><div className="big-metric"><strong>{p.metric}</strong><span>{p.label}</span></div></div><ProductMock project={p}/></div>
   <div className="project-next"><span>SELECTED PROJECT</span><b>0{project+1} / 03</b><button onClick={()=>setProject((project+1)%projects.length)}>NEXT PROJECT <MoveUpRight size={16}/></button></div>
  </section>
  <Ticker/>
  <section className="toolkit" id="toolkit"><div className="section-tag"><span>03 / THE TOOLBOX</span><span>SELECT A LAYER</span></div><div className="toolkit-layout"><div className="toolkit-intro"><span className="scribble">✳</span><h2>Curiosity<br/>is my <i>stack.</i></h2><p>Tools change. The instinct to understand how things fit together doesn't.</p><div className="toolkit-counter">0{group+1}<span> / 05</span></div></div><div className="toolbox"><div className="toolbox-head"><span><Layers3 size={16}/> ENGINEERING LAYERS</span><span>INTERACTIVE INDEX ↘</span></div>{groups.map((g,i)=><button key={g.name} className={group===i?'chosen':''} onClick={()=>setGroup(i)}><span className="layer-number">0{i+1}</span><span className="layer-name">{g.name}<small>{g.line}</small></span><span className="layer-items">{g.items.length} SKILLS</span><MoveUpRight size={17}/></button>)}<div className="skill-cloud" key={group}>{groups[group].items.map((s,i)=><span key={s} style={{'--i':i} as React.CSSProperties}>{s}</span>)}</div></div></div></section>
  <section className="research"><div className="section-tag"><span>04 / RESEARCH & CURIOSITY</span><span>BEYOND THE SCREEN</span></div><div className="research-grid"><div><span className="research-stamp">INCET / 2025</span><h2>AI WITH<br/><i>A HUMAN</i><br/>REASON.</h2></div><div className="research-detail"><div className="research-icon"><Code2 size={32}/></div><p>“Explainable AI Based Classification of Slow Learners and Remedial Teaching Methods” — research exploring how interpretable machine learning can support more informed educational interventions.</p><span>APPLIED AI · EXPLAINABLE ML · EDUCATION</span></div></div></section>
  <section className="contact"><div className="contact-spark">✳</div><div className="section-tag"><span>05 / YOUR MOVE</span><span>THE NEXT GOOD THING STARTS WITH A CONVERSATION</span></div><div className="contact-body"><Reveal><span className="contact-kicker">HAVE A CHALLENGE WORTH SOLVING?</span><h2>LET'S MAKE<br/><i>SOMETHING</i><br/>MATTER.</h2><a href="mailto:sasidharp394@gmail.com" className="contact-button">START A CONVERSATION <MoveUpRight size={19}/></a></Reveal></div><div className="contact-footer"><a href="mailto:sasidharp394@gmail.com">SASIDHARP394@GMAIL.COM</a><a href="https://github.com/Sasidhar-07" target="_blank" rel="noreferrer"><Github size={16}/> GITHUB</a><a href="https://linkedin.com/in/sasi03" target="_blank" rel="noreferrer"><Linkedin size={16}/> LINKEDIN</a><span>MADE WITH INTENT / INDIA {clock}</span></div></section>
  <footer><span>© 2026 PANNURU SASIDHAR</span><span>NOT A TEMPLATE. A WORK IN PROGRESS.</span><a href="#top">BACK TO TOP ↑</a></footer>
 </main>
}
